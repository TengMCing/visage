library(testthat)

test_check("visage")
